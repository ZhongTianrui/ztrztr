#include <bits/stdc++.h>
#include "include/make.hpp"
using namespace std;
int main() {
	ios::sync_with_stdio(false);
	pre();
	/*make your data here
	use cout in output
	*/
	cout << randint(1, 1e9) << " " << randint(1, 1e9);
	return 0;
}
