# florr-recode
Here is a java version of https://florr.io.
The project is under developing, so it is still unstable and incomplete.

# build
Just run `ant client` or `ant server`.

# dependencies
We use lwgjl3 to develop this software.