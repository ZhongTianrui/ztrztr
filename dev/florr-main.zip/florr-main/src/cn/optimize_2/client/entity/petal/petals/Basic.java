// package cn.optimize_2.client.entity.petal.petals;

// import cn.optimize_2.client.entity.petal.Petal;
// import cn.optimize_2.utils.state.GameState;

// public class Basic extends Petal {
// public static Integer dmg = 10;
// public static Integer dur = 10;

// public Basic(int flowerId, int id) {
// super(flowerId, GameState.basicTexture, id, dmg, dur);
// }
// }
