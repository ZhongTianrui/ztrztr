package cn.optimize_2.client.entity;

import cn.optimize_2.utils.graphic.Renderer;

public class Map {
    public static void render(Renderer renderer, float alpha) {

    }
}
