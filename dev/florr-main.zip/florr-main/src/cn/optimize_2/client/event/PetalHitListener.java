package cn.optimize_2.client.event;

public interface PetalHitListener {
    public void actionToFlowerHitEvent(PetalHitEvent petalHitEvent);
}
